﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PatientMonitor
{
    public enum PatientClassesEnumeration
    {
        PatientDataReader,
        PatientAlarmer,
        PatientData
    }
}
